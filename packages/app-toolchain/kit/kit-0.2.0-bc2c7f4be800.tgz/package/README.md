# App Builder core · 0.2.0

Working package identity: `@app-builder/core`. Not yet publicly published. The root identity.ts in the builder repository centralizes provisional names.

The root export provides validated action definitions, shared tRPC/MCP execution, Hono routes, auth, encrypted backend credentials and optional collection sharing. Import browser helpers only from `/react`, SSR loader helpers from `/ssr`, shared tables from `/schema`, native SQLite/runtime/backup helpers from `/node`, and D1/R2 helpers from `/worker`. Apps own their schema, permissions, actions, migrations and editable screens.

The `app-builder` CLI creates independent apps and supports dev, build, serve, migrations, Cloudflare deploy, backup/restore and an HTTP-to-stdio MCP bridge. Run it with `pnpm exec app-builder` for help. Generated projects include a locked dependency tree, pinned core tarball, AGENTS.md, a build skill and a runtime guide.

Before upgrading an existing app, make a backup, update the core dependency and lockfile, and run its populated-data and authorization tests. Keep application migrations immutable. The core's regression suite checks revoked/expired assistant credentials, two-user isolation, private files, both SQLite drivers and recovery. A fix in this package must remain effective after app customization.

New starters use React Router 7 framework mode for server rendering, with Vite and the existing Hono API on both runtimes. A core upgrade alone does not rewrite a customized app into SSR: legacy Vite SPA build/dev paths remain supported. Adopt the new starter's root, route modules, rendering entries and runtime wrappers explicitly when migrating an existing app.

Use `putCredential(ctx, key, value)`, `getCredential(ctx, key)` and `deleteCredential(ctx, key)` only on the backend. JSON values are encrypted with AES-256-GCM, a random nonce and authenticated owner/key binding. The installation secret is outside the database; changing it makes retained credentials require reconnection. First-account adoption rebinds local credentials. Portable backups omit the encrypted rows entirely. Sign-in account hooks discard access, refresh and ID tokens after authentication; features that need ongoing service access use the credential store with a separate grant. Google sign-in and direct service adapters are not enabled by the examples.
