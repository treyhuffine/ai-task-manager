import type { AppConfig } from "@app-builder/core";
export const appConfig: AppConfig = {
  id: "reading-log",
  name: "Reading Log",
  description: "A little room for everything you read.",
  port: 4310,
};
