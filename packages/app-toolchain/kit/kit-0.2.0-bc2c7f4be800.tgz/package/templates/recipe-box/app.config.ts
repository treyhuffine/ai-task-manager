import type { AppConfig } from "@app-builder/core";
export const appConfig: AppConfig = {
  id: "recipe-box", name: "Recipe Box",
  description: "Good food, worth keeping.", port: 4320,
};
