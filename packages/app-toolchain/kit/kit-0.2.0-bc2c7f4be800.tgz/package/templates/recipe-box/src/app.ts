import { z } from "zod/v3";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { collectionSources, defineAction, defineView, requireRole, readableSpaceIds, sharingActions, type Application } from "@app-builder/core";
import { files, spaces } from "@app-builder/core/schema";
import { appConfig } from "../app.config";
import { recipes } from "./schema";

const recipe = z.object({
  id: z.string(), spaceId: z.string(), userId: z.string(),
  title: z.string(), ingredients: z.string(), instructions: z.string(),
  createdAt: z.string(), updatedAt: z.string(),
});
const fields = {
  title: z.string().trim().min(1).max(240),
  ingredients: z.string().max(24000).default(""),
  instructions: z.string().max(48000).default(""),
};

export const application: Application = {
  config: appConfig,
  // Each assistant connection chooses which collections it may see. The core's
  // collection checks (requireRole, readableSpaceIds) apply that choice.
  sources: collectionSources,
  // Render tools: the model reads with list_recipes and calls this when the person should see recipes.
  views: [
    defineView({
      name: "show_recipes", title: "Show recipes",
      description: "Show the person recipes in an interactive card, where they can read each one and open the whole recipe box. Pass ids to show particular recipes (ones you just saved, found or changed), or a collectionId. Use it when seeing the recipes helps the person. To read recipes yourself, use list_recipes.",
      input: z.object({
        title: z.string().max(80).optional().describe('A short heading, such as "For Sunday" or "Saved just now".'),
        ids: z.array(z.string().uuid()).max(30).optional().describe("Show exactly these recipes, in this order."),
        collectionId: z.string().optional().describe("Without ids: only this collection's recipes."),
        limit: z.number().int().min(1).max(30).default(8).describe("Without ids: how many to show, newest first."),
      }),
      output: z.object({
        title: z.string(), more: z.boolean(),
        recipes: z.array(z.object({
          id: z.string(), title: z.string(), collection: z.string(), ingredients: z.string(), instructions: z.string(),
          photo: z.object({ id: z.string(), name: z.string() }).nullable(),
        })),
      }),
      invoking: "Getting your recipes", invoked: "Your recipes",
      handler: async (ctx, input) => {
        if (input.collectionId) await requireRole(ctx, input.collectionId, "viewer");
        const readable = sql`${recipes.spaceId} IN (${readableSpaceIds(ctx)})`;
        const rows = input.ids?.length
          ? (await ctx.platform.db.select().from(recipes).where(and(readable, inArray(recipes.id, input.ids))))
            .sort((a, b) => input.ids!.indexOf(a.id) - input.ids!.indexOf(b.id))
          : await ctx.platform.db.select().from(recipes).where(input.collectionId ? and(readable, eq(recipes.spaceId, input.collectionId)) : readable)
            .orderBy(desc(recipes.createdAt)).limit(input.limit + 1);
        const more = !input.ids?.length && rows.length > input.limit;
        const shown = more ? rows.slice(0, input.limit) : rows;
        const photos = shown.length ? await ctx.platform.db.select().from(files).where(inArray(files.parentId, shown.map((row) => row.id))) : [];
        const names = shown.length ? await ctx.platform.db.select({ id: spaces.id, name: spaces.name }).from(spaces).where(inArray(spaces.id, [...new Set(shown.map((row) => row.spaceId))])) : [];
        return {
          summary: shown.length ? `Showed ${shown.length}${more ? "+" : ""} ${shown.length === 1 ? "recipe" : "recipes"}: ${shown.slice(0, 10).map((row) => row.title).join("; ")}${shown.length > 10 ? "; …" : ""}.` : "No recipes match, so the card says so.",
          data: {
            title: input.title ?? (input.collectionId ? names[0]?.name ?? "Recipes" : "Your recipes"), more,
            recipes: shown.map((row) => {
              const photo = photos.find((file) => file.parentId === row.id);
              return { id: row.id, title: row.title, collection: names.find((space) => space.id === row.spaceId)?.name ?? "", ingredients: row.ingredients, instructions: row.instructions, photo: photo ? { id: photo.id, name: photo.name } : null };
            }),
          },
        };
      },
    }),
  ],
  async exportData(ctx) {
    const own = await ctx.platform.db.select().from(recipes).where(and(
      eq(recipes.userId, ctx.viewer.id), sql`${recipes.spaceId} IN (${readableSpaceIds(ctx)})`,
    ));
    const photos = await ctx.platform.db.select({ id: files.id }).from(files).where(and(
      eq(files.ownerId, ctx.viewer.id),
      sql`${files.parentId} IN (SELECT id FROM recipes WHERE space_id IN (${readableSpaceIds(ctx)}))`,
    ));
    return { records: { recipes: own }, fileIds: photos.map((photo) => photo.id) };
  },
  migrations: [{
    id: "app-0001",
    sql: `CREATE TABLE recipes (
      id TEXT PRIMARY KEY, space_id TEXT NOT NULL REFERENCES spaces(id),
      user_id TEXT NOT NULL REFERENCES users(id), title TEXT NOT NULL,
      ingredients TEXT NOT NULL, instructions TEXT NOT NULL,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
      -- statement-breakpoint
      CREATE INDEX recipes_space_date_idx ON recipes(space_id,created_at DESC);`,
  }],
  async authorizeFile(ctx, file, operation) {
    const [parent] = await ctx.platform.db.select().from(recipes).where(eq(recipes.id, file.parentId));
    if (!parent) return false;
    try {
      const role = await requireRole(ctx, parent.spaceId, operation === "write" ? "contributor" : "viewer");
      return operation === "read" || role === "owner" || parent.userId === ctx.viewer.id;
    }
    catch { return false; }
  },
  actions: [
    ...sharingActions,
    defineAction({
      name: "list_recipes", title: "Recipes", description: "List recipes in collections this person can read.",
      input: z.object({ spaceId: z.string().optional() }),
      output: z.array(recipe.extend({ canEdit: z.boolean(), photos: z.array(z.object({ id: z.string(), name: z.string() })) })),
      effect: "read", retry: "safe", audience: ["user", "agent"],
      handler: async (ctx, input) => {
        if (input.spaceId) await requireRole(ctx, input.spaceId, "viewer");
        const rows = await ctx.platform.db.select().from(recipes).where(
          input.spaceId ? eq(recipes.spaceId, input.spaceId) : sql`${recipes.spaceId} IN (${readableSpaceIds(ctx)})`,
        ).orderBy(desc(recipes.createdAt)).limit(60);
        const photos = rows.length ? await ctx.platform.db.select().from(files).where(inArray(files.parentId, rows.map((row) => row.id))) : [];
        const { spaces } = await import("@app-builder/core/schema");
        const owned = await ctx.platform.db.select({ id: spaces.id }).from(spaces).where(eq(spaces.ownerId, ctx.viewer.id));
        return rows.map((row) => ({ ...row, canEdit: row.userId === ctx.viewer.id || owned.some((space) => space.id === row.spaceId), photos: photos.filter((photo) => photo.parentId === row.id).map(({ id, name }) => ({ id, name })) }));
      },
    }),
    defineAction({
      name: "save_recipe", title: "Save a recipe", description: "Add a recipe to a collection. Keep its ID when retrying.",
      input: z.object({ id: z.string().uuid(), spaceId: z.string(), ...fields }), output: recipe,
      effect: "write", retry: "safe", audience: ["user", "agent"],
      handler: async (ctx, input) => {
        await requireRole(ctx, input.spaceId, "contributor");
        const timestamp = new Date().toISOString();
        await ctx.platform.db.insert(recipes).values({ ...input, userId: ctx.viewer.id, createdAt: timestamp, updatedAt: timestamp }).onConflictDoNothing();
        const [saved] = await ctx.platform.db.select().from(recipes).where(and(eq(recipes.id, input.id), eq(recipes.spaceId, input.spaceId), eq(recipes.userId, ctx.viewer.id)));
        if (!saved) throw new TRPCError({ code: "CONFLICT", message: "Choose a new recipe ID." });
        return saved;
      },
    }),
    defineAction({
      name: "update_recipe", title: "Update a recipe", description: "Edit your own recipe, or any recipe in a collection you own.",
      input: z.object({ id: z.string().uuid(), expectedUpdatedAt: z.string().datetime(), ...fields }), output: recipe,
      effect: "write", retry: "unsafe", audience: ["user", "agent"],
      handler: async (ctx, { id, expectedUpdatedAt, ...changes }) => {
        const [current] = await ctx.platform.db.select().from(recipes).where(eq(recipes.id, id));
        if (!current) throw new TRPCError({ code: "NOT_FOUND", message: "Recipe unavailable." });
        const role = await requireRole(ctx, current.spaceId, "contributor");
        if (role !== "owner" && current.userId !== ctx.viewer.id)
          throw new TRPCError({ code: "FORBIDDEN", message: "You can edit recipes you added." });
        const updatedAt = new Date(Math.max(Date.now(), Date.parse(expectedUpdatedAt) + 1)).toISOString();
        const [updated] = await ctx.platform.db.update(recipes).set({ ...changes, updatedAt })
          .where(and(eq(recipes.id, id), eq(recipes.updatedAt, expectedUpdatedAt))).returning();
        if (!updated) throw new TRPCError({ code: "CONFLICT", message: "This recipe changed. Refresh before saving." });
        return updated;
      },
    }),
  ],
};
