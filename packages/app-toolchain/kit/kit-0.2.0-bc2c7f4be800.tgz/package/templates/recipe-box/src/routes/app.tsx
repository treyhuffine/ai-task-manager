export { Kitchen as default } from "../screens";
