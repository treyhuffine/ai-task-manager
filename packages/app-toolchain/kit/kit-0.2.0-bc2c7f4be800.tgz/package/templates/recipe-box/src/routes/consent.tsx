export { ConsentScreen as default } from "@app-builder/core/react";
