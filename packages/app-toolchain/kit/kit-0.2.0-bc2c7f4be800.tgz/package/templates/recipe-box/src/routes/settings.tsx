export { ConnectionSettings as default } from "@app-builder/core/react";
