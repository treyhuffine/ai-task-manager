import { sqliteTable, text } from "drizzle-orm/sqlite-core";
import { users, spaces } from "@app-builder/core/schema";
export const recipes = sqliteTable("recipes", {
  id: text("id").primaryKey(),
  spaceId: text("space_id").notNull().references(() => spaces.id),
  userId: text("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  ingredients: text("ingredients").notNull(),
  instructions: text("instructions").notNull(),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
});
