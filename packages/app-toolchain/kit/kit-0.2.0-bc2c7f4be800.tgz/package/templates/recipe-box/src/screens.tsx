import React, { useEffect, useState } from "react";
import { Link, Route, Routes } from "react-router";
import { useAction, useAppClient, ConnectionSettings, ConsentScreen, PendingSaves, Modal, Button, Photo, Form, ViewCard } from "@app-builder/core/react";
import { appConfig } from "../app.config";

import type { recipes } from "./schema";
import type { spaces, files } from "@app-builder/core/schema";
type Collection = typeof spaces.$inferSelect & { role: "owner" | "contributor" | "viewer" };
type Recipe = typeof recipes.$inferSelect & { canEdit: boolean; photos: Pick<typeof files.$inferSelect, "id" | "name">[] };

export function Kitchen() {
  const client = useAppClient();
  const collections = useAction<Collection[]>("list_collections");
  const [collectionId, setCollectionId] = useState("");
  const recipes = useAction<Recipe[]>("list_recipes", collectionId ? { spaceId: collectionId } : {});
  const [selected, setSelected] = useState<Recipe | null>(null);
  const [adding, setAdding] = useState(false);
  const [naming, setNaming] = useState(false);
  const [editing, setEditing] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [inviteURL, setInviteURL] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const current = collections.data?.find((collection) => collection.id === collectionId);
  const writable = collections.data?.filter((collection) => collection.role !== "viewer") ?? [];
  const members = useAction<{ userId: string; name: string; role: string }[]>("list_members", { spaceId: collectionId }, { enabled: sharing && current?.role === "owner" });
  useEffect(() => () => client.select(null), [client.select]);
  const select = (recipe: Recipe | null) => {
    setSelected(recipe); setEditing(false); setError("");
    client.select(recipe ? { id: recipe.id, title: recipe.title } : null);
  };
  // A dialog rather than window.prompt, which an assistant's sandboxed frame blocks.
  const addCollection = () => { setError(""); setNaming(true); };
  return <div className="workspace"><header className="app-header"><Link className="brand" to="/"><span className="brand-mark" aria-hidden="true">◒</span>{appConfig.name}</Link>{!client.embedded && <Link className="settings-link" to="/settings">Settings</Link>}</header>
    <main className="library"><div className="page-heading"><div><h1>Good food, worth keeping.</h1><p className="subtitle">A collection of recipes to make, share, and make again.</p></div><Button className="primary" onClick={() => { if (!writable.length) addCollection(); else setAdding(true); }}>{writable.length ? "＋ Add a recipe" : "Start a collection"}</Button></div>
      <PendingSaves /><div className="toolbar recipe-toolbar"><div className="tabs"><button className={!collectionId ? "tab active" : "tab"} onClick={() => setCollectionId("")}>All recipes</button>{collections.data?.map((collection) => <button key={collection.id} className={collectionId === collection.id ? "tab active" : "tab"} onClick={() => setCollectionId(collection.id)}>{collection.name}</button>)}<button className="tab" aria-label="New collection" onClick={addCollection}>＋</button></div>{!client.embedded && current?.role === "owner" && <button className="text-button" onClick={() => setSharing(true)}>Share collection</button>}</div>
      {(error || recipes.error || collections.error) && <p role="alert" className="error">{error || recipes.error || collections.error}</p>}
      {recipes.loading ? <p className="empty">Opening your recipe box…</p> : recipes.data?.length ? <div className="recipe-grid">{recipes.data.map((recipe, index) => <button className="recipe-card" key={recipe.id} onClick={() => select(recipe)}><div className={`recipe-image recipe-color-${index % 4}`}>{recipe.photos[0] ? <Photo id={recipe.photos[0].id} alt={recipe.photos[0].name} /> : <span aria-hidden="true">◒</span>}</div><h2>{recipe.title}</h2><p>{collections.data?.find((collection) => collection.id === recipe.spaceId)?.name}</p></button>)}</div> : <div className="empty-state"><span className="empty-book" aria-hidden="true">◒</span><h2>A home for your favorites.</h2><p>{collections.data?.length ? "Save the first recipe you want to come back to." : "Create a collection for your own recipes or a shared family table."}</p><Button className="primary" onClick={() => { if (!collections.data?.length) addCollection(); else setAdding(true); }}>{collections.data?.length ? "Add your first recipe" : "Create a collection"}</Button></div>}
    </main>
    {naming && <Modal open={naming} onOpenChange={setNaming} title="New collection"><Form onSubmit={async (form) => {
      setBusy(true); setError("");
      try {
        const collection = await client.call<Collection>("create_collection", { id: crypto.randomUUID(), name: String(form.get("name")).trim() });
        client.didChange(`Started the collection “${collection.name}”`);
        setNaming(false); await collections.refresh(); setCollectionId(collection.id);
      } catch (error) { setError((error as Error).message); } finally { setBusy(false); }
    }}><label>Collection name<input autoFocus name="name" defaultValue="My recipes" required maxLength={100} /></label>{error && <p className="error" role="alert">{error}</p>}<Button className="primary" disabled={busy}>{busy ? "Creating…" : "Create collection"}</Button></Form></Modal>}
    {adding && <Modal open={adding} onOpenChange={setAdding} title="Save a recipe"><Form onSubmit={async (form) => {
      setBusy(true); setError("");
      try {
        const id = crypto.randomUUID();
        const file = form.get("photo");
        const uploads = file instanceof File && file.size ? [{ id: crypto.randomUUID(), parentId: id, file }] : [];
        await client.save("save_recipe", { id, spaceId: form.get("spaceId"), title: form.get("title"), ingredients: form.get("ingredients"), instructions: form.get("instructions") }, uploads);
        client.didChange(`Saved the recipe “${String(form.get("title"))}”`);
        setAdding(false); await recipes.refresh();
      } catch (error) { setError((error as Error).message); } finally { setBusy(false); }
    }}><label>Title<input autoFocus name="title" placeholder="Your favorite thing to cook" required maxLength={240} /></label><label>Collection<select name="spaceId" defaultValue={writable.some((collection) => collection.id === collectionId) ? collectionId : writable[0]?.id}>{writable.map((collection) => <option value={collection.id} key={collection.id}>{collection.name}</option>)}</select></label><label>Ingredients<textarea name="ingredients" rows={4} maxLength={24000} placeholder="One ingredient per line" /></label><label>Method<textarea name="instructions" rows={5} maxLength={48000} placeholder="How do you make it?" /></label>{!client.embedded && <label>Photo<input type="file" name="photo" accept="image/jpeg,image/png,image/webp" /></label>}{error && <p className="error" role="alert">{error}</p>}<Button className="primary" disabled={busy}>{busy ? "Saving…" : "Save recipe"}</Button></Form></Modal>}
    {selected && <aside className="detail-panel"><button className="close" aria-label="Close recipe" onClick={() => select(null)}>×</button><p className="eyebrow">{collections.data?.find((collection) => collection.id === selected.spaceId)?.name}</p>{editing ? <Form onSubmit={async (form) => {
      setBusy(true); setError("");
      try {
        const updated = await client.call<Omit<Recipe, "photos" | "canEdit">>("update_recipe", { id: selected.id, expectedUpdatedAt: selected.updatedAt, title: form.get("title"), ingredients: form.get("ingredients"), instructions: form.get("instructions") });
        select({ ...selected, ...updated }); client.didChange(`Edited the recipe “${updated.title}”`); await recipes.refresh();
      } catch (error) { setError((error as Error).message); } finally { setBusy(false); }
    }}><h2>Edit recipe</h2><label>Title<input name="title" defaultValue={selected.title} required maxLength={240} /></label><label>Ingredients<textarea name="ingredients" defaultValue={selected.ingredients} rows={5} maxLength={24000} /></label><label>Method<textarea name="instructions" defaultValue={selected.instructions} rows={7} maxLength={48000} /></label>{error && <p className="error" role="alert">{error}</p>}<Button className="primary" disabled={busy}>Save changes</Button><button type="button" className="text-button" onClick={() => setEditing(false)}>Cancel</button></Form> : <><h2>{selected.title}</h2>{selected.photos[0] && <Photo className="detail-photo" id={selected.photos[0].id} alt={selected.photos[0].name} />}<h3>Ingredients</h3><p className="recipe-text">{selected.ingredients || "Add the ingredients when you’re ready."}</p><h3>Method</h3><p className="recipe-text">{selected.instructions || "A little intuition goes a long way."}</p>{selected.canEdit && <Button className="secondary" onClick={() => setEditing(true)}>Edit recipe</Button>}</>}</aside>}
    {sharing && current && <Modal open={sharing} onOpenChange={(open) => { setSharing(open); if (!open) setInviteURL(""); }} title={"Share " + current.name}><p>Invite someone to this collection.</p>{client.localOwner ? <p>First <Link className="text-button" to="/settings">enable sign-in in Settings</Link>, then run the app at an address your guests can reach.</p> : <Form onSubmit={async (form) => {
      setBusy(true);
      try { const result = await client.call<{ url: string }>("invite_to_collection", { spaceId: current.id, role: form.get("role") }); setInviteURL(result.url); } catch (error) { setError((error as Error).message); } finally { setBusy(false); }
    }}><label>They can<select name="role"><option value="contributor">Add their own recipes</option><option value="viewer">View recipes</option></select></label><Button className="primary" disabled={busy}>Create invitation</Button></Form>}{inviteURL && <><p>This invitation works once and expires in seven days.</p><input aria-label="Invitation link" value={inviteURL} readOnly /><button className="secondary" onClick={() => void navigator.clipboard.writeText(inviteURL)}>Copy invitation</button></>}{error && <p className="error" role="alert">{error}</p>}{!!members.data?.length && <section><h3>People with access</h3>{members.data.map((member) => <div className="connection-row" key={member.userId}><span>{member.name} · {member.role}</span><button className="text-button" onClick={async () => {
      try { await client.call("remove_member", { spaceId: current.id, userId: member.userId }); await members.refresh(); }
      catch (error) { setError((error as Error).message); }
    }}>Remove access</button></div>)}</section>}</Modal>}
  </div>;
}
type CardRecipe = { id: string; title: string; collection: string; ingredients: string; instructions: string; photo: { id: string; name: string } | null };
/** The card show_recipes draws in a chat: tap a recipe to read it. */
export function RecipesCard({ data }: { data: { title: string; recipes: CardRecipe[]; more: boolean } }) {
  const client = useAppClient();
  const [open, setOpen] = useState("");
  useEffect(() => () => client.select(null), [client.select]);
  return <ViewCard title={data.title} count={data.recipes.length ? `${data.recipes.length}${data.more ? "+" : ""}` : undefined} footer={data.more ? `More in your ${client.config.name}.` : undefined}>
    {data.recipes.length ? <ul className="view-list">{data.recipes.map((recipe) => <li key={recipe.id} className="view-recipe">
      <button type="button" className="view-row" aria-expanded={open === recipe.id} onClick={() => {
        const next = open === recipe.id ? "" : recipe.id;
        setOpen(next);
        client.select(next ? { id: recipe.id, title: recipe.title } : null);
      }}>
        <span className="view-thumb">{recipe.photo ? <Photo id={recipe.photo.id} alt={recipe.photo.name} /> : <span aria-hidden="true">◒</span>}</span>
        <span className="view-row-body"><strong>{recipe.title}</strong><span>{recipe.collection}</span></span>
      </button>
      {open === recipe.id && <div className="view-recipe-text"><h2>Ingredients</h2><p>{recipe.ingredients || "Not written down yet."}</p><h2>Method</h2><p>{recipe.instructions || "Not written down yet."}</p></div>}
    </li>)}</ul> : <p className="view-empty">No recipes match.</p>}
  </ViewCard>;
}
/** Cards for the app's show_* tools. Anything else in an assistant draws the whole app. */
export const viewCards = { show_recipes: RecipesCard };

export function Invitation() {
  const client = useAppClient();
  const [message, setMessage] = useState("");
  return <main className="auth-screen"><section><h1>A place at the table.</h1><p>Accept this invitation to open the shared collection.</p><Button className="primary" onClick={async () => {
    try { await client.call("accept_invite", { token: location.pathname.split("/").pop() }); location.assign("/"); } catch (error) { setMessage((error as Error).message); }
  }}>Accept invitation</Button>{message && <p className="error" role="alert">{message}</p>}</section></main>;
}

export function AppScreens() { return <Routes><Route path="/" element={<Kitchen />} /><Route path="/settings" element={<ConnectionSettings />} /><Route path="/oauth/consent" element={<ConsentScreen />} /><Route path="/invite/:token" element={<Invitation />} /><Route path="*" element={<Kitchen />} /></Routes>; }
