CREATE TABLE IF NOT EXISTS _migrations (id TEXT PRIMARY KEY, checksum TEXT NOT NULL, applied_at TEXT NOT NULL);
CREATE TABLE recipes (
      id TEXT PRIMARY KEY, space_id TEXT NOT NULL REFERENCES spaces(id),
      user_id TEXT NOT NULL REFERENCES users(id), title TEXT NOT NULL,
      ingredients TEXT NOT NULL, instructions TEXT NOT NULL,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
      

      CREATE INDEX recipes_space_date_idx ON recipes(space_id,created_at DESC);
INSERT INTO _migrations (id,checksum,applied_at) VALUES ('app-0001','785ce4f3751a109a16eca4f89ef38653f0b91bca178392c5c591e947f2070e1b',CURRENT_TIMESTAMP);
