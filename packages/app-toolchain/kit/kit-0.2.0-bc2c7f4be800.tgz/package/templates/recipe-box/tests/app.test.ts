import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createActionRouter, createApp, type Context } from "@app-builder/core";
import { createTestConnection, openNodePlatform } from "@app-builder/core/node";
import { application } from "../src/app";

test("a recipe create is safe to retry, survives a restart and is readable through MCP", async () => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "recipe-app-test-"));
  let opened = await openNodePlatform(application, { dataDir, localOwner: true });
  try {
    const context: Context = { platform: opened.platform, viewer: { id: "local-owner", name: "You", email: "owner@localhost" }, request: new Request(opened.platform.baseURL) };
    const caller = createActionRouter(application, "user").createCaller(context);
    const spaceId = crypto.randomUUID(), id = crypto.randomUUID();
    await caller.run({ name: "create_collection", input: { id: spaceId, name: "My recipes" } });
    for (let retry = 0; retry < 2; retry++) await caller.run({ name: "save_recipe", input: { id, spaceId, title: "Soup" } });
    opened.close(); opened = await openNodePlatform(application, { dataDir, localOwner: true });
    const app = createApp(application, () => opened.platform);
    // Every MCP request needs a connection's token, also on this computer.
    const { accessToken } = await createTestConnection(opened.platform);
    const response = await app.request(opened.platform.baseURL + "/mcp", {
      method: "POST", headers: { "content-type": "application/json", accept: "application/json, text/event-stream", authorization: "Bearer " + accessToken },
      body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/call", params: { name: "list_recipes", arguments: {} } }),
    });
    const result = await response.json() as { result: { structuredContent: { result: { id: string }[] } } };
    assert.deepEqual(result.result.structuredContent.result.map((record) => record.id), [id]);
  } finally { opened.close(); await fs.rm(dataDir, { recursive: true, force: true }); }
});
